# Sticky Notifications

A simple native Android app project.

## Features
- Add a notification with custom text.
- Saves notification text locally on the phone.
- Restores saved notifications when the app is opened.
- Delete saved entries from the app.
- Requests Android notification permission on Android 13 and newer.

## Build an APK
1. Open this folder in Android Studio.
2. Let Gradle sync finish.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find the APK using the "locate" link in Android Studio.

## Important behaviour
Android notifications may be dismissed by the user or by system settings. This app stores the messages locally and re-posts saved messages when opened again if they are no longer active. Android may restrict notification display until notification permission is granted. Xiaomi HyperOS may also have battery or notification settings that affect delivery.

Package: com.boss.stickynotifications
