package com.boss.stickynotifications

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.os.Build
import org.json.JSONArray

object Notifier {
    const val CHANNEL_NORMAL = "user_notes"
    const val CHANNEL_STICKY = "sticky_notes"
    const val DEFAULT_APP_NAME = "Sticky Notifications"

    fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences("saved_notes", Context.MODE_PRIVATE)

    fun appName(context: Context): String {
        val name = prefs(context).getString("app_name", DEFAULT_APP_NAME)
        return if (name.isNullOrEmpty()) DEFAULT_APP_NAME else name
    }

    fun isSticky(context: Context): Boolean = prefs(context).getBoolean("sticky", false)

    fun readNotes(context: Context): JSONArray = try {
        JSONArray(prefs(context).getString("notes", "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val normal = NotificationChannel(
            CHANNEL_NORMAL, "My notifications", NotificationManager.IMPORTANCE_DEFAULT
        )
        normal.description = "Notifications created in the app"
        manager.createNotificationChannel(normal)

        val sticky = NotificationChannel(
            CHANNEL_STICKY, "Sticky notifications", NotificationManager.IMPORTANCE_LOW
        )
        sticky.description = "Notifications that stay on your lock screen"
        sticky.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        sticky.setShowBadge(false)
        manager.createNotificationChannel(sticky)
    }

    fun show(context: Context, id: Int, title: String, message: String) {
        ensureChannels(context)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val sticky = isSticky(context)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

        val openApp = PendingIntent.getActivity(
            context, id, Intent(context, MainActivity::class.java), flags
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, if (sticky) CHANNEL_STICKY else CHANNEL_NORMAL)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context)
        }
        val logo = BitmapFactory.decodeResource(context.resources, R.drawable.logo)
        builder
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setLargeIcon(logo)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(Notification.BigTextStyle().bigText(message))
            .setContentIntent(openApp)
            .setCategory(Notification.CATEGORY_REMINDER)
            .setOnlyAlertOnce(true)

        if (sticky) {
            // If the user swipes it away anyway (Android 14+ allows this), the receiver puts it back.
            val repost = PendingIntent.getBroadcast(
                context, id + 500000,
                Intent(context, RepostReceiver::class.java).putExtra("id", id), flags
            )
            builder
                .setOngoing(true)
                .setAutoCancel(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setDeleteIntent(repost)
        } else {
            builder
                .setOngoing(false)
                .setAutoCancel(true)
        }
        manager.notify(id, builder.build())
    }
}
