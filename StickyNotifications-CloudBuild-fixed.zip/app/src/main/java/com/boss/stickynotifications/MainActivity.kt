package com.boss.stickynotifications

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

class MainActivity : Activity() {
    private val channelId = "user_notes"
    private val prefs by lazy { getSharedPreferences("saved_notes", Context.MODE_PRIVATE) }
    private lateinit var input: EditText
    private lateinit var listContainer: LinearLayout
    private var nextId = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        nextId = prefs.getInt("next_id", 1)
        buildUi()
        requestNotificationPermissionIfNeeded()
        restoreNotifications()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(Color.rgb(247, 248, 252))
        }

        val title = TextView(this).apply {
            text = "Sticky Notifications"
            textSize = 25f
            setTextColor(Color.rgb(30, 35, 50))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Create notifications that stay in your notification centre."
            textSize = 14f
            setTextColor(Color.rgb(95, 101, 118))
            setPadding(0, dp(8), 0, dp(20))
        }
        root.addView(subtitle)

        input = EditText(this).apply {
            hint = "Type your notification..."
            textSize = 16f
            minLines = 2
            maxLines = 5
            gravity = Gravity.TOP
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(input, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val addButton = Button(this).apply {
            text = "Add notification"
            isAllCaps = false
            setOnClickListener { addNotification() }
        }
        val buttonParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        buttonParams.topMargin = dp(12)
        root.addView(addButton, buttonParams)

        val sectionTitle = TextView(this).apply {
            text = "Saved notifications"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(30, 35, 50))
            setPadding(0, dp(24), 0, dp(8))
        }
        root.addView(sectionTitle)

        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listContainer)

        val note = TextView(this).apply {
            text = "Tip: notifications can be dismissed from Android's notification shade. Saved entries remain here and are restored when you reopen the app."
            textSize = 12f
            setTextColor(Color.rgb(105, 110, 125))
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(note)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.rgb(247, 248, 252))
            addView(root)
        }
        scroll.setOnApplyWindowInsetsListener { _, insets ->
            @Suppress("DEPRECATION")
            val top = insets.systemWindowInsetTop
            @Suppress("DEPRECATION")
            val bottom = insets.systemWindowInsetBottom
            root.setPadding(dp(22), dp(28) + top, dp(22), dp(20) + bottom)
            insets
        }
        setContentView(scroll)
        refreshList()
    }

    private fun addNotification() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) {
            Toast.makeText(this, "Type a message first.", Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
            Toast.makeText(this, "Allow notifications, then tap Add notification again.", Toast.LENGTH_LONG).show()
            return
        }

        val id = nextId++
        prefs.edit().putInt("next_id", nextId).apply()
        val notes = readNotes()
        notes.put(org.json.JSONObject().put("id", id).put("message", message))
        saveNotes(notes)
        showNotification(id, message)
        input.text.clear()
        refreshList()
        Toast.makeText(this, "Notification added.", Toast.LENGTH_SHORT).show()
    }

    private fun showNotification(id: Int, message: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.app.Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            android.app.Notification.Builder(this)
        }
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Your notification")
            .setContentText(message)
            .setStyle(android.app.Notification.BigTextStyle().bigText(message))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setCategory(android.app.Notification.CATEGORY_REMINDER)
            .build()
        manager.notify(id, notification)
    }

    private fun restoreNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        // Re-post saved notifications only if Android no longer has them displayed.
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val activeIds = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            manager.activeNotifications.map { it.id }.toSet()
        } else emptySet()
        val notes = readNotes()
        for (i in 0 until notes.length()) {
            val item = notes.optJSONObject(i) ?: continue
            val id = item.optInt("id")
            val message = item.optString("message")
            if (id !in activeIds) showNotification(id, message)
        }
    }

    private fun refreshList() {
        if (!::listContainer.isInitialized) return
        listContainer.removeAllViews()
        val notes = readNotes()
        if (notes.length() == 0) {
            listContainer.addView(TextView(this).apply {
                text = "No notifications yet."
                textSize = 14f
                setTextColor(Color.GRAY)
            })
            return
        }
        for (i in notes.length() - 1 downTo 0) {
            val item = notes.optJSONObject(i) ?: continue
            val id = item.optInt("id")
            val message = item.optString("message")
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(8), dp(8))
                setBackgroundColor(Color.WHITE)
            }
            val messageView = TextView(this).apply {
                text = message
                textSize = 15f
                setTextColor(Color.rgb(35, 40, 55))
            }
            row.addView(messageView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val delete = Button(this).apply {
                text = "Delete"
                isAllCaps = false
                setOnClickListener {
                    val updated = readNotes()
                    for (j in updated.length() - 1 downTo 0) {
                        if (updated.optJSONObject(j)?.optInt("id") == id) updated.remove(j)
                    }
                    saveNotes(updated)
                    (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id)
                    refreshList()
                }
            }
            row.addView(delete)
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            params.bottomMargin = dp(8)
            listContainer.addView(row, params)
        }
    }

    private fun readNotes(): JSONArray = try {
        JSONArray(prefs.getString("notes", "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    private fun saveNotes(notes: JSONArray) {
        prefs.edit().putString("notes", notes.toString()).apply()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "My notifications", NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications created in Sticky Notifications"
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
