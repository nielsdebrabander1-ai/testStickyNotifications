package com.boss.stickynotifications

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.Icon
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private val pickBackgroundCode = 77
    private val prefs by lazy { Notifier.prefs(this) }
    private lateinit var headerView: TextView
    private lateinit var appNameInput: EditText
    private lateinit var titleInput: EditText
    private lateinit var input: EditText
    private lateinit var listContainer: LinearLayout
    private var nextId = 1

    // Colours, filled in by loadPalette()
    private var cBackground = 0
    private var cCard = 0
    private var cText = 0
    private var cSubText = 0
    private val cWarning = Color.rgb(214, 110, 20)

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(
            if (isDark()) android.R.style.Theme_Material_NoActionBar
            else android.R.style.Theme_Material_Light_NoActionBar
        )
        super.onCreate(savedInstanceState)
        Notifier.ensureChannels(this)
        nextId = prefs.getInt("next_id", 1)
        buildUi()
        requestNotificationPermissionIfNeeded()
        restoreNotifications()
    }

    // ---------- Theme ----------

    private fun isDark(): Boolean {
        val saved = prefs.getInt("dark_mode", -1)
        if (saved != -1) return saved == 1
        val mode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return mode == Configuration.UI_MODE_NIGHT_YES
    }

    private fun loadPalette() {
        val dark = isDark()
        cBackground = if (dark) Color.rgb(16, 18, 26) else Color.rgb(247, 248, 252)
        cCard = if (dark) Color.rgb(30, 33, 46) else Color.WHITE
        cText = if (dark) Color.rgb(238, 240, 248) else Color.rgb(30, 35, 50)
        cSubText = if (dark) Color.rgb(165, 171, 190) else Color.rgb(95, 101, 118)
    }

    private fun applySystemBars(dark: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val controller = window.insetsController
            if (controller != null) {
                val flags = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                controller.setSystemBarsAppearance(if (dark) 0 else flags, flags)
            }
        }
    }

    // ---------- UI helpers ----------

    private fun appName(): String = Notifier.appName(this)

    private fun styledEdit(hintText: String, minLineCount: Int, maxLineCount: Int): EditText {
        val edit = EditText(this)
        edit.hint = hintText
        edit.textSize = 16f
        edit.minLines = minLineCount
        edit.maxLines = maxLineCount
        edit.gravity = Gravity.TOP
        edit.setTextColor(cText)
        edit.setHintTextColor(cSubText)
        edit.setPadding(dp(14), dp(12), dp(14), dp(12))
        edit.setBackgroundColor(cCard)
        return edit
    }

    private fun label(labelText: String): TextView {
        val view = TextView(this)
        view.text = labelText
        view.textSize = 13f
        view.setTextColor(cSubText)
        view.setPadding(0, dp(16), 0, dp(6))
        return view
    }

    private fun sectionHeader(headerText: String): TextView {
        val view = TextView(this)
        view.text = headerText
        view.textSize = 18f
        view.setTypeface(null, android.graphics.Typeface.BOLD)
        view.setTextColor(cText)
        view.setPadding(0, dp(24), 0, dp(0))
        return view
    }

    private fun smallNote(noteText: String, color: Int): TextView {
        val view = TextView(this)
        view.text = noteText
        view.textSize = 12f
        view.setTextColor(color)
        view.setPadding(0, dp(6), 0, dp(4))
        return view
    }

    private fun buildUi() {
        loadPalette()
        val dark = isDark()
        val matchParent = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(22), dp(28), dp(22), dp(20))

        headerView = TextView(this)
        headerView.text = appName()
        headerView.textSize = 25f
        headerView.setTextColor(cText)
        headerView.setTypeface(null, android.graphics.Typeface.BOLD)
        root.addView(headerView)

        val subtitle = TextView(this)
        subtitle.text = "Create notifications that stay in your notification centre."
        subtitle.textSize = 14f
        subtitle.setTextColor(cSubText)
        subtitle.setPadding(0, dp(8), 0, dp(4))
        root.addView(subtitle)

        // --- New notification ---
        root.addView(label("Notification title"))
        titleInput = styledEdit("Title (leave empty to use the app name)", 1, 2)
        titleInput.id = 1001
        root.addView(titleInput, LinearLayout.LayoutParams(matchParent, wrap))

        root.addView(label("Message"))
        input = styledEdit("Type your notification...", 2, 5)
        input.id = 1002
        root.addView(input, LinearLayout.LayoutParams(matchParent, wrap))

        val addButton = Button(this)
        addButton.text = "Add notification"
        addButton.isAllCaps = false
        addButton.setOnClickListener { addNotification() }
        val addParams = LinearLayout.LayoutParams(matchParent, wrap)
        addParams.topMargin = dp(12)
        root.addView(addButton, addParams)

        // --- Saved notifications ---
        root.addView(sectionHeader("Saved notifications"))
        listContainer = LinearLayout(this)
        listContainer.orientation = LinearLayout.VERTICAL
        val listParams = LinearLayout.LayoutParams(matchParent, wrap)
        listParams.topMargin = dp(8)
        root.addView(listContainer, listParams)

        // --- Settings ---
        root.addView(sectionHeader("Settings"))

        val darkSwitch = Switch(this)
        darkSwitch.text = "Dark mode"
        darkSwitch.textSize = 16f
        darkSwitch.setTextColor(cText)
        darkSwitch.isChecked = dark
        darkSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putInt("dark_mode", if (checked) 1 else 0).apply()
            recreate()
        }
        val switchParams = LinearLayout.LayoutParams(matchParent, wrap)
        switchParams.topMargin = dp(12)
        root.addView(darkSwitch, switchParams)

        val stickySwitch = Switch(this)
        stickySwitch.text = "Keep messages on lock screen"
        stickySwitch.textSize = 16f
        stickySwitch.setTextColor(cText)
        stickySwitch.isChecked = Notifier.isSticky(this)
        stickySwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("sticky", checked).apply()
            repostAll()
        }
        val stickyParams = LinearLayout.LayoutParams(matchParent, wrap)
        stickyParams.topMargin = dp(16)
        root.addView(stickySwitch, stickyParams)
        root.addView(
            smallNote(
                "Your notifications stay in the notification shade and on the lock screen until you delete them here. " +
                    "Warning: Android must also allow this app to show notifications on the lock screen " +
                    "(Settings > Notifications > this app > Lock screen). " +
                    "On Android 14 and newer a swipe can still remove it, but the app puts it right back.",
                cWarning
            )
        )

        // --- Background ---
        root.addView(label("Background"))
        val bgRow = LinearLayout(this)
        bgRow.orientation = LinearLayout.HORIZONTAL
        val chooseBg = Button(this)
        chooseBg.text = "Choose background"
        chooseBg.isAllCaps = false
        chooseBg.setOnClickListener { pickBackground() }
        bgRow.addView(chooseBg, LinearLayout.LayoutParams(0, wrap, 1f))
        val removeBg = Button(this)
        removeBg.text = "Remove"
        removeBg.isAllCaps = false
        removeBg.setOnClickListener { removeBackground() }
        bgRow.addView(removeBg, LinearLayout.LayoutParams(0, wrap, 1f))
        root.addView(bgRow, LinearLayout.LayoutParams(matchParent, wrap))

        // --- App name ---
        root.addView(sectionHeader("App name"))
        root.addView(label("Shown in the app and on a new home screen icon"))
        appNameInput = styledEdit("App name", 1, 1)
        appNameInput.id = 1003
        appNameInput.setText(appName())
        root.addView(appNameInput, LinearLayout.LayoutParams(matchParent, wrap))

        val saveNameButton = Button(this)
        saveNameButton.text = "Save name"
        saveNameButton.isAllCaps = false
        saveNameButton.setOnClickListener { saveAppName() }
        val saveParams = LinearLayout.LayoutParams(matchParent, wrap)
        saveParams.topMargin = dp(8)
        root.addView(saveNameButton, saveParams)

        val shortcutButton = Button(this)
        shortcutButton.text = "Add icon with this name to home screen"
        shortcutButton.isAllCaps = false
        shortcutButton.setOnClickListener { addHomeShortcut() }
        root.addView(shortcutButton, LinearLayout.LayoutParams(matchParent, wrap))

        root.addView(
            smallNote(
                "Warning: this only works if your phone allows it. On Xiaomi and similar phones, turn on " +
                    "\"Home screen shortcuts\" (or \"Create shortcuts\") under Settings > Apps > this app > Other permissions. " +
                    "Without that permission nothing will appear.",
                cWarning
            )
        )
        root.addView(
            smallNote(
                "Android does not let an app rename its own icon, so the new icon is a shortcut with your name. " +
                    "You can remove the original icon from your home screen.",
                cSubText
            )
        )

        // --- Layout: background image + veil + scrolling content ---
        val frame = FrameLayout(this)
        frame.setBackgroundColor(cBackground)

        val bgFile = File(filesDir, "background.jpg")
        if (bgFile.exists()) {
            val bitmap = BitmapFactory.decodeFile(bgFile.absolutePath)
            if (bitmap != null) {
                val image = ImageView(this)
                image.scaleType = ImageView.ScaleType.CENTER_CROP
                image.setImageBitmap(bitmap)
                frame.addView(image, FrameLayout.LayoutParams(matchParent, matchParent))
                val veil = View(this)
                veil.setBackgroundColor(
                    if (dark) Color.argb(150, 0, 0, 0) else Color.argb(150, 255, 255, 255)
                )
                frame.addView(veil, FrameLayout.LayoutParams(matchParent, matchParent))
            }
        }

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(root)
        frame.addView(scroll, FrameLayout.LayoutParams(matchParent, matchParent))

        frame.setOnApplyWindowInsetsListener { _, insets ->
            @Suppress("DEPRECATION")
            val top = insets.systemWindowInsetTop
            @Suppress("DEPRECATION")
            val bottom = insets.systemWindowInsetBottom
            root.setPadding(dp(22), dp(28) + top, dp(22), dp(20) + bottom)
            insets
        }
        setContentView(frame)
        applySystemBars(dark)
        refreshList()
    }

    // ---------- Background picture ----------

    private fun pickBackground() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "image/*"
        startActivityForResult(intent, pickBackgroundCode)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickBackgroundCode && resultCode == Activity.RESULT_OK) {
            val uri = data?.data
            if (uri != null) saveBackground(uri)
        }
    }

    private fun readRotation(uri: Uri): Float {
        return try {
            val exif = contentResolver.openInputStream(uri)?.use { ExifInterface(it) }
            when (exif?.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
    }

    private fun saveBackground(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val longest = maxOf(bounds.outWidth, bounds.outHeight)
            while (longest / sample > 2048) sample *= 2

            val options = BitmapFactory.Options()
            options.inSampleSize = sample
            val decoded = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            }
            if (decoded == null) {
                Toast.makeText(this, "Could not read that picture.", Toast.LENGTH_SHORT).show()
                return
            }
            val rotation = readRotation(uri)
            val finalBitmap: Bitmap = if (rotation != 0f) {
                val matrix = Matrix()
                matrix.postRotate(rotation)
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
            } else {
                decoded
            }
            FileOutputStream(File(filesDir, "background.jpg")).use { out ->
                finalBitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)
            }
            recreate()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not set that picture.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun removeBackground() {
        val file = File(filesDir, "background.jpg")
        if (file.exists()) file.delete()
        recreate()
    }

    // ---------- App name + shortcut ----------

    private fun saveAppName() {
        val name = appNameInput.text.toString().trim()
        if (name.isEmpty()) {
            Toast.makeText(this, "Type a name first.", Toast.LENGTH_SHORT).show()
            return
        }
        prefs.edit().putString("app_name", name).apply()
        headerView.text = name
        Toast.makeText(this, "Name saved.", Toast.LENGTH_SHORT).show()
    }

    private fun addHomeShortcut() {
        val name = appNameInput.text.toString().trim().ifEmpty { appName() }
        val manager = getSystemService(Context.SHORTCUT_SERVICE) as? ShortcutManager
        if (manager == null || !manager.isRequestPinShortcutSupported) {
            Toast.makeText(this, "Your launcher does not support home screen shortcuts.", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().putString("app_name", name).apply()
        headerView.text = name
        val launch = Intent(this, MainActivity::class.java).setAction(Intent.ACTION_MAIN)
        val logo = BitmapFactory.decodeResource(resources, R.drawable.logo)
        val info = ShortcutInfo.Builder(this, "home_" + System.currentTimeMillis())
            .setShortLabel(name)
            .setIcon(Icon.createWithBitmap(logo))
            .setIntent(launch)
            .build()
        val requested = manager.requestPinShortcut(info, null)
        if (requested) {
            Toast.makeText(this, "Confirm adding the icon. If nothing appears, allow home screen shortcuts for this app in Android settings.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Could not add the icon. Allow home screen shortcuts for this app in Android settings.", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- Notifications ----------

    private fun hasNotificationPermission(): Boolean {
        return Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    private fun addNotification() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) {
            Toast.makeText(this, "Type a message first.", Toast.LENGTH_SHORT).show()
            return
        }
        if (!hasNotificationPermission()) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
            Toast.makeText(this, "Allow notifications, then tap Add notification again.", Toast.LENGTH_LONG).show()
            return
        }

        val title = titleInput.text.toString().trim().ifEmpty { appName() }
        val id = nextId++
        prefs.edit().putInt("next_id", nextId).apply()
        val notes = readNotes()
        notes.put(JSONObject().put("id", id).put("title", title).put("message", message))
        saveNotes(notes)
        Notifier.show(this, id, title, message)
        input.text.clear()
        refreshList()
        Toast.makeText(this, "Notification added.", Toast.LENGTH_SHORT).show()
    }

    // Re-post every saved note, e.g. after the lock screen setting changed.
    private fun repostAll() {
        if (!hasNotificationPermission()) return
        val notes = readNotes()
        for (i in 0 until notes.length()) {
            val item = notes.optJSONObject(i) ?: continue
            val title = item.optString("title").ifEmpty { appName() }
            Notifier.show(this, item.optInt("id"), title, item.optString("message"))
        }
    }

    private fun restoreNotifications() {
        if (!hasNotificationPermission()) return
        // Re-post saved notifications only if Android no longer has them displayed.
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val activeIds = manager.activeNotifications.map { it.id }.toSet()
        val notes = readNotes()
        for (i in 0 until notes.length()) {
            val item = notes.optJSONObject(i) ?: continue
            val id = item.optInt("id")
            val title = item.optString("title").ifEmpty { appName() }
            val message = item.optString("message")
            if (id !in activeIds) Notifier.show(this, id, title, message)
        }
    }

    private fun refreshList() {
        if (!::listContainer.isInitialized) return
        listContainer.removeAllViews()
        val notes = readNotes()
        if (notes.length() == 0) {
            val empty = TextView(this)
            empty.text = "No notifications yet."
            empty.textSize = 14f
            empty.setTextColor(cSubText)
            listContainer.addView(empty)
            return
        }
        for (i in notes.length() - 1 downTo 0) {
            val item = notes.optJSONObject(i) ?: continue
            val id = item.optInt("id")
            val title = item.optString("title").ifEmpty { appName() }
            val message = item.optString("message")

            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(8), dp(8), dp(8))
            row.setBackgroundColor(cCard)

            val column = LinearLayout(this)
            column.orientation = LinearLayout.VERTICAL
            val titleView = TextView(this)
            titleView.text = title
            titleView.textSize = 13f
            titleView.setTypeface(null, android.graphics.Typeface.BOLD)
            titleView.setTextColor(cSubText)
            val messageView = TextView(this)
            messageView.text = message
            messageView.textSize = 15f
            messageView.setTextColor(cText)
            column.addView(titleView)
            column.addView(messageView)
            row.addView(column, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val delete = Button(this)
            delete.text = "Delete"
            delete.isAllCaps = false
            delete.setOnClickListener {
                val updated = readNotes()
                for (j in updated.length() - 1 downTo 0) {
                    if (updated.optJSONObject(j)?.optInt("id") == id) updated.remove(j)
                }
                saveNotes(updated)
                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id)
                refreshList()
            }
            row.addView(delete)

            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            params.bottomMargin = dp(8)
            listContainer.addView(row, params)
        }
    }

    private fun readNotes(): JSONArray = Notifier.readNotes(this)

    private fun saveNotes(notes: JSONArray) {
        prefs.edit().putString("notes", notes.toString()).apply()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (!hasNotificationPermission()) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
