package com.boss.stickynotifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Puts a sticky notification back when the user swipes it away.
class RepostReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!Notifier.isSticky(context)) return
        val id = intent.getIntExtra("id", -1)
        if (id < 0) return
        val notes = Notifier.readNotes(context)
        for (i in 0 until notes.length()) {
            val item = notes.optJSONObject(i) ?: continue
            if (item.optInt("id") == id) {
                val title = item.optString("title").ifEmpty { Notifier.appName(context) }
                Notifier.show(context, id, title, item.optString("message"))
                return
            }
        }
    }
}
