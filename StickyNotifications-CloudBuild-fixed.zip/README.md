# Sticky Notifications

A simple native Android app project.

## Build the APK without a PC using GitHub Actions
This project includes `.github/workflows/build-apk.yml` so GitHub's cloud runner can build the APK.

1. Open GitHub in your phone browser and sign in.
2. Create a repository, then upload all project files and folders from this ZIP, including `.github/workflows/build-apk.yml`.
3. Open the repository's **Actions** tab and select **Build Android APK**. Enable workflows if prompted, then tap **Run workflow**. A push to `main` also starts a build.
4. When the run finishes successfully, open that run and download the **StickyNotifications-debug-apk** artifact.
5. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from the browser or file manager.

## Features
- Add notifications with custom text.
- Saves messages locally.
- Re-posts saved notifications when the app is reopened if they are no longer active.
- Delete saved entries from the app.
- Requests notification permission on Android 13+.

Android can dismiss notifications, and Xiaomi HyperOS settings may affect delivery.
Package: com.boss.stickynotifications
